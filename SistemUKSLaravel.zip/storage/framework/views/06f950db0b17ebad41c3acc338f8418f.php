<?php $__env->startSection('title', 'Catat Kunjungan Baru'); ?>
<?php $__env->startSection('page_title', 'Form Pencatatan Kunjungan UKS'); ?>
<?php $__env->startSection('page_description', 'Isi data kunjungan siswa, kondisi fisik, pemeriksaan tanda vital, dan tindakan penanganan'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div class="p-6 sm:p-8 border-b border-slate-100 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                </div>
                <div>
                    <h3 class="text-base font-bold text-slate-900">Rekam Kunjungan Baru</h3>
                    <p class="text-xs text-slate-400">Pastikan seluruh data kondisi dan tindakan tercatat dengan akurat</p>
                </div>
            </div>
            <a href="<?php echo e(route('admin.visits.index')); ?>" class="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors">
                Kembali
            </a>
        </div>

        <form action="<?php echo e(route('admin.visits.store')); ?>" method="POST" class="p-6 sm:p-8 space-y-8">
            <?php echo csrf_field(); ?>

            <!-- 1. IDENTITAS SISWA -->
            <div>
                <h4 class="text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50/70 px-3 py-1.5 rounded-lg inline-block mb-4">
                    1. Identitas Siswa
                </h4>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="md:col-span-2">
                        <label for="student_id" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                            Pilih Siswa <span class="text-rose-500">*</span>
                        </label>
                        <select id="student_id" name="student_id" required class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 bg-white">
                            <option value="">-- Pilih Siswa (Ketik / Gulir) --</option>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>" <?php echo e(old('student_id', request('student_id')) == $s->id ? 'selected' : ''); ?>>
                                    <?php echo e($s->name); ?> — [<?php echo e($s->nis); ?>] — <?php echo e($s->schoolClass->name ?? 'Tanpa Kelas'); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="text-[11px] text-slate-400 mt-1">Siswa belum terdaftar? <a href="<?php echo e(route('admin.students.create')); ?>" target="_blank" class="text-emerald-600 underline font-semibold">Tambah data siswa baru di sini</a>.</p>
                        <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- 2. WAKTU & JADWAL KUNJUNGAN -->
            <div class="pt-6 border-t border-slate-100">
                <h4 class="text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50/70 px-3 py-1.5 rounded-lg inline-block mb-4">
                    2. Waktu Kunjungan
                </h4>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <!-- Tanggal -->
                    <div>
                        <label for="visit_date" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Tanggal <span class="text-rose-500">*</span></label>
                        <input type="date" id="visit_date" name="visit_date" value="<?php echo e(old('visit_date', date('Y-m-d'))); ?>" required
                            class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <?php $__errorArgs = ['visit_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Jam Datang -->
                    <div>
                        <label for="arrival_time" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Jam Datang <span class="text-rose-500">*</span></label>
                        <input type="time" id="arrival_time" name="arrival_time" value="<?php echo e(old('arrival_time', date('H:i'))); ?>" required
                            class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <?php $__errorArgs = ['arrival_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Jam Selesai -->
                    <div>
                        <label for="departure_time" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Jam Selesai (Opsional)</label>
                        <input type="time" id="departure_time" name="departure_time" value="<?php echo e(old('departure_time')); ?>"
                            class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <p class="text-[11px] text-slate-400 mt-1">Kosongkan jika siswa masih berada di UKS</p>
                    </div>

                    <!-- Jam Pelajaran Ke- -->
                    <div>
                        <label for="lesson_period" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Jam Pelajaran Ke <span class="text-rose-500">*</span></label>
                        <select id="lesson_period" name="lesson_period" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 bg-white">
                            <option value="">-- Pilih Jam Ke --</option>
                            <?php $__currentLoopData = $lessonPeriods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($period); ?>" <?php echo e(old('lesson_period') == $period ? 'selected' : ''); ?>><?php echo e($period); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['lesson_period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Guru / Mata Pelajaran -->
                    <div class="sm:col-span-2">
                        <label for="subject" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Mata Pelajaran / Guru Mengajar</label>
                        <input type="text" id="subject" name="subject" value="<?php echo e(old('subject')); ?>" placeholder="Contoh: Matematika / Bu Sri"
                            class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                    </div>
                </div>
            </div>

            <!-- 3. KONDISI & TANDA VITAL -->
            <div class="pt-6 border-t border-slate-100">
                <h4 class="text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50/70 px-3 py-1.5 rounded-lg inline-block mb-4">
                    3. Kondisi Siswa & Pemeriksaan Fisik
                </h4>

                <div class="space-y-4">
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <!-- Jenis Keluhan -->
                        <div>
                            <label for="complaint_type" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Jenis Keluhan Utama <span class="text-rose-500">*</span></label>
                            <select id="complaint_type" name="complaint_type" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 bg-white">
                                <option value="">-- Pilih Keluhan --</option>
                                <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($c); ?>" <?php echo e(old('complaint_type') == $c ? 'selected' : ''); ?>><?php echo e($c); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['complaint_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Suhu Tubuh -->
                        <div>
                            <label for="temperature" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Suhu Tubuh (°C)</label>
                            <input type="number" step="0.1" id="temperature" name="temperature" value="<?php echo e(old('temperature')); ?>" placeholder="Misal: 36.5"
                                class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                            <?php $__errorArgs = ['temperature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Tekanan Darah -->
                        <div>
                            <label for="blood_pressure" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Tekanan Darah (mmHg)</label>
                            <input type="text" id="blood_pressure" name="blood_pressure" value="<?php echo e(old('blood_pressure')); ?>" placeholder="Misal: 120/80"
                                class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        </div>
                    </div>

                    <!-- Kondisi Umum -->
                    <div>
                        <label for="general_condition" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Kondisi Umum Siswa</label>
                        <input type="text" id="general_condition" name="general_condition" value="<?php echo e(old('general_condition')); ?>" placeholder="Contoh: Sadar penuh, tampak pucat, mengantuk, bibir kering..."
                            class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                    </div>

                    <!-- Rincian Keluhan -->
                    <div>
                        <label for="complaint" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Deskripsi / Rincian Keluhan Siswa <span class="text-rose-500">*</span></label>
                        <textarea id="complaint" name="complaint" rows="3" required placeholder="Jelaskan apa yang dirasakan siswa, sejak kapan timbul keluhan, dll..."
                            class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"><?php echo e(old('complaint')); ?></textarea>
                        <?php $__errorArgs = ['complaint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- 4. TINDAKAN PETUGAS & STATUS AKHIR -->
            <div class="pt-6 border-t border-slate-100">
                <h4 class="text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50/70 px-3 py-1.5 rounded-lg inline-block mb-4">
                    4. Tindakan Petugas & Status Akhir
                </h4>

                <div class="space-y-4">
                    <!-- Template Tindakan Cepat -->
                    <div>
                        <label class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Pilihan Tindakan Cepat (Klik untuk menambah)</label>
                        <div class="flex flex-wrap gap-1.5">
                            <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" onclick="appendTreatment('<?php echo e($t); ?>')" class="px-2.5 py-1 text-xs rounded-lg bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-700 transition-colors font-medium border border-slate-200">
                                    + <?php echo e($t); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Textarea Tindakan -->
                    <div>
                        <label for="treatment" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Tindakan / Penanganan yang Diberikan <span class="text-rose-500">*</span></label>
                        <textarea id="treatment" name="treatment" rows="3" required placeholder="Tindakan yang diberikan petugas (obat, kompres, istirahat, dll)..."
                            class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"><?php echo e(old('treatment')); ?></textarea>
                        <?php $__errorArgs = ['treatment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Status Akhir -->
                    <div>
                        <label for="final_status" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Status Setelah Kunjungan <span class="text-rose-500">*</span></label>
                        <select id="final_status" name="final_status" required class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 bg-white font-semibold">
                            <option value="">-- Pilih Status Akhir --</option>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($st); ?>" <?php echo e(old('final_status', 'Kembali ke kelas') == $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['final_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Catatan Tambahan -->
                    <div>
                        <label for="notes" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Catatan Tambahan</label>
                        <textarea id="notes" name="notes" rows="2" placeholder="Catatan pesan untuk wali kelas / orang tua siswa..."
                            class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"><?php echo e(old('notes')); ?></textarea>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="pt-6 border-t border-slate-100 flex flex-col-reverse sm:flex-row sm:items-center justify-end gap-3">
                <a href="<?php echo e(route('admin.visits.index')); ?>" class="w-full sm:w-auto text-center px-5 py-3 sm:py-2.5 text-xs font-bold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors">
                    Batal
                </a>
                <button type="submit" class="w-full sm:w-auto justify-center px-6 py-3 sm:py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                    <span>Simpan Data Kunjungan</span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function appendTreatment(text) {
        const area = document.getElementById('treatment');
        if (area.value.trim() === '') {
            area.value = text;
        } else {
            area.value += ', ' + text;
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Music\SistemUKSLaravel\resources\views/admin/visits/create.blade.php ENDPATH**/ ?>