<?php $__env->startSection('title', 'Tambah Kelas Baru'); ?>
<?php $__env->startSection('page_title', 'Tambah Rombongan Belajar / Kelas'); ?>
<?php $__env->startSection('page_description', 'Daftarkan kelas baru, tingkat jenjang, dan nama wali kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto">
    <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div class="p-6 sm:p-8 border-b border-slate-100 flex items-center justify-between">
            <h3 class="text-base font-bold text-slate-900">Form Data Kelas Baru</h3>
            <a href="<?php echo e(route('admin.classes.index')); ?>" class="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors">
                Kembali
            </a>
        </div>

        <form action="<?php echo e(route('admin.classes.store')); ?>" method="POST" class="p-6 sm:p-8 space-y-5">
            <?php echo csrf_field(); ?>

            <div>
                <label for="name" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Nama Kelas <span class="text-rose-500">*</span></label>
                <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required placeholder="Contoh: X PPLG 1"
                    class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label for="grade" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Tingkat Jenjang <span class="text-rose-500">*</span></label>
                    <select id="grade" name="grade" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 bg-white">
                        <option value="X" <?php echo e(old('grade') === 'X' ? 'selected' : ''); ?>>Tingkat X</option>
                        <option value="XI" <?php echo e(old('grade') === 'XI' ? 'selected' : ''); ?>>Tingkat XI</option>
                        <option value="XII" <?php echo e(old('grade') === 'XII' ? 'selected' : ''); ?>>Tingkat XII</option>
                    </select>
                </div>

                <div>
                    <label for="status" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Status <span class="text-rose-500">*</span></label>
                    <select id="status" name="status" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 bg-white">
                        <option value="active" <?php echo e(old('status') === 'active' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="inactive" <?php echo e(old('status') === 'inactive' ? 'selected' : ''); ?>>Nonaktif</option>
                    </select>
                </div>
            </div>

            <div>
                <label for="major" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Program Keahlian / Jurusan <span class="text-rose-500">*</span></label>
                <input type="text" id="major" name="major" value="<?php echo e(old('major')); ?>" required placeholder="Contoh: Rekayasa Perangkat Lunak"
                    class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                <?php $__errorArgs = ['major'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-rose-600 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="homeroom_teacher" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Nama Wali Kelas</label>
                <input type="text" id="homeroom_teacher" name="homeroom_teacher" value="<?php echo e(old('homeroom_teacher')); ?>" placeholder="Contoh: Dra. Sri Wahyuni, M.Pd"
                    class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
            </div>

            <div class="pt-4 border-t border-slate-100 flex flex-col-reverse sm:flex-row sm:items-center justify-end gap-3">
                <a href="<?php echo e(route('admin.classes.index')); ?>" class="w-full sm:w-auto text-center px-4 py-2.5 text-xs font-bold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors">
                    Batal
                </a>
                <button type="submit" class="w-full sm:w-auto justify-center px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors">
                    Simpan Kelas
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Music\SistemUKSLaravel\resources\views/admin/classes/create.blade.php ENDPATH**/ ?>